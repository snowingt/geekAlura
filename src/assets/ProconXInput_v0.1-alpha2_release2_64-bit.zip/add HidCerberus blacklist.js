// wscript javascript code that sends a POST request to HidCerberus.Srv
// requesting HidGuardian to block the hardware ID of the Switch Procon

// Create request object
var http = WScript.CreateObject('Msxml2.XMLHTTP.6.0');

// Various constants
var url = "http://localhost:26762/api/v1/hidguardian/affected/add/";
var request = "hwids=HID%5CVID_057E%26PID_2009";
var contentType = "application/x-www-form-urlencoded; charset=UTF-8";

http.open("POST", url, false)
http.setRequestHeader("Content-Type", contentType);
http.setRequestHeader("Content-Length", request.length)
http.send(request)

WScript.Quit(0);
