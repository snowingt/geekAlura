NOTICE
======

If you have installed ScpToolkit previously, or installed ScpVBus before, 
you don't need to install it again. If there is a device under 
`System devices` named `Scp Vitrual Bus Driver` in the Device Manager, some
version of ScpVBus (not necessarily a compatible one!) is installed.

If you've used other programs which generate XInput devices on demand, they
might have installed ScpVBus, hopefully a compatible version. One program
which does this is WiinUSoft. If you run the `uninstall ScpVBus.bat`script,
it will remove ANY version of ScpVBus installed, and will break any
programs which rely on it.


### Installation

**Note: Once you install the drivers, don't move the ProconXInput folder.
This is because the HidCerberus.Srv service is installed to this folder
and won't work if you move it.**

To automate the process, right click `install Drivers.bat` and select
`Run as administrator` to install.

To manually install, run the following commands as an administrator from
the ProconXInput folder:

- `.\Drivers\devcon.exe install ScpVBus\ScpVBus.inf Root\ScpVBus`
- `.\Drivers\devcon.exe install HidGuardian\Hidguardian.inf Root\HidGuardian`
- `.\Drivers\devcon.exe classfilter HIDClass upper -HidGuardian`
- `.\HidCerberus.Srv\HidCerberus.Srv.exe install`


### Removal

To automate the process, right click `uninstall Drivers.bat` and select
`Run as administrator` to uninstall, then delete the ProconXInput folder.

To manually uninstall, run the following commands as an administrator from
the ProconXInput folder: 

- `.\Drivers\devcon.exe remove Root\ScpVBus`
- `.\Drivers\devcon.exe remove Root\HidGuardian`
- `.\Drivers\devcon.exe classfilter HIDClass upper !HidGuardian`
- `.\HidCerberus.Srv\HidCerberus.Srv.exe uninstall`

Then you're free to delete the ProconXInput folder.
